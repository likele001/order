App({
  onLaunch: function () {
    // 小程序启动逻辑
    this.globalData = {
      apiUrl: 'https://your-domain.com/api/', // 替换为你的后端API地址
      userInfo: null
    };
  },
  // 登录函数（与FastAdmin集成）
  login: function (cb) {
    const that = this;
    wx.login({
      success: res => {
        wx.request({
          url: that.globalData.apiUrl + 'user/login',
          method: 'POST',
          data: { code: res.code },
          success: res => {
            if (res.data.code === 0) {
              that.globalData.userInfo = res.data.data;
              wx.setStorageSync('userInfo', res.data.data);
              typeof cb == "function" && cb(that.globalData.userInfo);
            } else {
              wx.showToast({ title: '登录失败', icon: 'none' });
            }
          }
        });
      }
    });
  }
});