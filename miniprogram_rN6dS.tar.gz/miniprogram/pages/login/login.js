Page({
  onLoad: function () {
    const app = getApp();
    app.login(userInfo => {
      wx.redirectTo({ url: '/pages/index/index' });
    });
  }
});