Page({
  data: { tasks: [], loading: false },
  onLoad: function () {
    this.loadTasks();
  },
  onPullDownRefresh: function () {
    this.loadTasks(() => wx.stopPullDownRefresh());
  },
  loadTasks: function (cb) {
    const app = getApp();
    const userInfo = wx.getStorageSync('userInfo');
    this.setData({ loading: true });
    wx.request({
      url: app.globalData.apiUrl + 'worker/tasks',
      header: { 'Authorization': userInfo.token },
      success: res => {
        if (res.data.code === 0) {
          this.setData({ tasks: res.data.data });
        } else {
          wx.showToast({ title: res.data.msg || '加载失败', icon: 'none' });
        }
      },
      fail: () => wx.showToast({ title: '网络错误', icon: 'none' }),
      complete: () => {
        this.setData({ loading: false });
        if (cb) cb();
      }
    });
  }
});