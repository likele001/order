// records.js
Page({
  data: { records: [] },
  onLoad: function() {
    this.loadRecords();
  },
  loadRecords: function() {
    wx.request({
      url: 'https://your-domain.com/api/worker/records',
      success: res => {
        if (res.data.success) {
          this.setData({ records: res.data.records });
        }
      }
    });
  }
});