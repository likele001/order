Page({
  data: { allocation: {}, quantity: '', remark: '', images: [], loading: false },
  onLoad: function (options) {
    this.loadAllocation(options.id);
  },
  loadAllocation: function (id) {
    const app = getApp();
    const userInfo = wx.getStorageSync('userInfo');
    wx.request({
      url: app.globalData.apiUrl + 'worker/report?id=' + id,
      header: { 'Authorization': userInfo.token },
      success: res => { if (res.data.code === 0) this.setData({ allocation: res.data.data }); }
    });
  },
  setQuantity: function (e) { this.setData({ quantity: e.detail.value }); },
  setRemark: function (e) { this.setData({ remark: e.detail.value }); },
  chooseImage: function () {
    const that = this;
    wx.chooseImage({
      count: 9 - that.data.images.length,
      success: res => {
        // 上传图片到服务器
        const app = getApp();
        const userInfo = wx.getStorageSync('userInfo');
        let uploaded = [];
        let files = res.tempFilePaths;
        let uploadCount = 0;
        wx.showLoading({ title: '上传中...' });
        files.forEach((file, idx) => {
          wx.uploadFile({
            url: app.globalData.apiUrl + 'worker/upload_image',
            filePath: file,
            name: 'file',
            header: { 'Authorization': userInfo.token },
            success: res2 => {
              const data = JSON.parse(res2.data);
              if (data.code === 0) {
                uploaded.push(data.data.url);
              }
              uploadCount++;
              if (uploadCount === files.length) {
                wx.hideLoading();
                that.setData({ images: that.data.images.concat(uploaded) });
              }
            },
            fail: () => {
              uploadCount++;
              if (uploadCount === files.length) wx.hideLoading();
            }
          });
        });
      }
    });
  },
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.url,
      urls: this.data.images
    });
  },
  removeImage: function (e) {
    const idx = e.currentTarget.dataset.idx;
    let imgs = this.data.images;
    imgs.splice(idx, 1);
    this.setData({ images: imgs });
  },
  submitReport: function () {
    if (!this.data.quantity || isNaN(this.data.quantity) || Number(this.data.quantity) <= 0) {
      wx.showToast({ title: '请输入有效数量', icon: 'none' });
      return;
    }
    this.setData({ loading: true });
    const app = getApp();
    const userInfo = wx.getStorageSync('userInfo');
    wx.request({
      url: app.globalData.apiUrl + 'worker/submit',
      method: 'POST',
      header: { 'Authorization': userInfo.token },
      data: { allocation_id: this.data.allocation.id, quantity: this.data.quantity, remark: this.data.remark, images: this.data.images },
      success: res => {
        if (res.data.code === 0) {
          wx.showToast({ title: '提交成功' });
          setTimeout(() => wx.navigateBack(), 1000);
        } else {
          wx.showToast({ title: res.data.msg || '提交失败', icon: 'none' });
        }
      },
      fail: () => wx.showToast({ title: '网络错误', icon: 'none' }),
      complete: () => this.setData({ loading: false })
    });
  }
});