Page({
  data: { user: {}, todayTaskCount: 0, todayReportCount: 0, todayWage: 0, today: '' },
  onLoad: function () {
    const app = getApp();
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo) { wx.redirectTo({ url: '/pages/login/login' }); return; }
    this.setData({ user: userInfo, today: new Date().toLocaleDateString() });
    this.loadStats();
  },
  loadStats: function () {
    const app = getApp();
    wx.request({
      url: app.globalData.apiUrl + 'worker/index',
      header: { 'Authorization': this.data.user.token },
      success: res => { if (res.data.code === 0) this.setData(res.data.data); }
    });
  }
});