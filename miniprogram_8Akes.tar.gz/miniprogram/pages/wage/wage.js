// wage.js
Page({
  data: { wages: [], total: 0 },
  onLoad: function() {
    this.loadWages();
  },
  loadWages: function() {
    wx.request({
      url: 'https://your-domain.com/api/worker/wages',
      success: res => {
        if (res.data.success) {
          this.setData({ wages: res.data.wages, total: res.data.total });
        }
      }
    });
  }
});